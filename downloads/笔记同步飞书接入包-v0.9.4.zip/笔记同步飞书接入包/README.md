# minmin-notehelper-feishu-starter

把微信里想保存的资料转发给自己的「笔记同步助手」，由 Agent 读取整理、保存到飞书。首次接入、图文指引、测试和后续定时同步，都由 Agent 带着完成。

**当前版本：v0.9.4** · [下载新版接入包](https://tools.minmin11538.cn/notehelper/downloads/笔记同步飞书接入包-v0.9.4.zip) · [更新说明](CHANGELOG.md) · [完整图文步骤](notebook-feishu-onboarding/references/grouped-messages.md)

## 国内下载与一句话接入

[打开国内下载页和说明书](https://tools.minmin11538.cn/notehelper/)。网页、完整 ZIP 和操作图片均由此域名提供，下载包不跳转 GitHub。

直接把下面这句话发给可联网、下载文件并执行本机命令的 Agent：

```text
请打开 https://tools.minmin11538.cn/notehelper/ ，下载并校验完整接入包；网页读取失败时自动用命令行 HTTPS 获取 https://tools.minmin11538.cn/notehelper/install.md 和同目录 release.json 继续下载。读取包内 notebook-feishu-onboarding/SKILL.md，带我完成微信转发到飞书的接入、测试和定时同步；已有飞书连接直接复用，需要我操作时把整组动作和图片一次发齐。
```

网页读取失败时，Agent 自动改用命令行 HTTPS 获取本站 install.md 与 release.json，校验完整包后继续。接入完成后，日常微信转发和定时同步不需要再打开下载网页。

## 拿到包怎么用

### 1. 下载，发给 Agent

下载上方 ZIP，直接发给 WorkBuddy 等能读取附件、运行本机命令并联网的 Agent。也可以先解压，把文件夹的安装路径发给 Agent，让它读取里面的 `notebook-feishu-onboarding/SKILL.md`。

你只需要准备自己的微信、飞书账号，以及一条愿意用于测试的资料。这里默认你已经会把附件或本机路径交给 Agent。

### 2. 复制这段话，一起发送

```text
请读取包里的 notebook-feishu-onboarding/SKILL.md。先检查飞书 CLI 是否已经接好，能用就直接复用；缺登录补登录、缺权限补权限，只有确实没有合适应用时才创建应用。带我在微信关注笔记同步助手、取得自己的密钥、添加自己的助手好友，再转发一条我指定的资料。由你读取整理，保存到我确认的飞书位置并读回验证。安装、命令和配置由你完成；需要我操作时，把同一组可连续完成的动作和对应图片一次发齐，讲清整组做完后一次回复什么，不要每点一个按钮都让我回来确认。微信添加好友后带我置顶接收资料的助手，方便以后转发；微信转发和飞书配置也按组交接。配官方说明书链接，用户示例截图说明出处。我提问时先查对应官方说明再回答。密钥可在对话框提供，先说明聊天与工具记录可能留存，不回显密钥。只走微信转发入口，不展开其它入口或可选安装。请按包内通用模板创建我的选题池、剪辑版本、发布与数据看板；保留完整正文、图片、改写和版本，手动和定时共用流程。配置完成后主动带我亲自转发测试，写入飞书并读回后让我打开验收；测试通过，再确认同步频率和保存位置，按包创建增量定时任务，从任务本身试跑并核对去重。当前窗口不支持时准备固定目录的续接说明，引导进入支持定时的入口，不让我重新配置，也不假装已设置成功。最后报告哪些已验证，哪些仍待完成。
```

### 3. 按 Agent 的图文指引操作

安装、环境检查、命令、配置文件和读回验证交给 Agent。需要你本人做的操作会按组发送：**一组连续动作和对应图片一次发齐，做完后一次回复；遇到报错随时告诉 Agent。**

| 阶段 | Agent 会帮你做什么 | 需要你做什么 |
| --- | --- | --- |
| 检查飞书 | 检查现有 CLI、登录和权限，能用就复用 | 只有缺少登录或授权时，本人确认 |
| 接入笔记同步助手 | 展示操作示意及官方原图，保存并验证密钥 | 微信关注服务号、发送 `Obsidian`、复制自己的密钥、添加并置顶助手好友 |
| 转发测试 | 读取选定条目，写入你确认的飞书位置并读回 | 转发一条资料，等云端完成后告诉 Agent 标题；打开飞书文档验收 |
| 设置定时 | 按确认的频率和位置建立增量任务，后台试跑并检查去重 | 确认同步频率、保存位置，处理宿主确实要求本人完成的操作 |

已接好飞书的用户会跳过重复创建应用；这条链路不需要安装 Obsidian。密钥来自你自己的开通消息，可在自己的 Agent 对话框提供；发送前 Agent 会说明聊天和工具记录可能留存，不会回显密钥。

## 接好后如何收集

**微信打开资料 → 转发给置顶的助手好友 → 笔记同步助手云端处理完成 → 定时 Agent 拉取新增资料 → 飞书正文与选题索引。**

接收资料的是你自己添加的助手好友；服务号负责开通和处理通知。看到菜单“取消置顶”表示已经置顶，保持即可，不用点取消。具体微信按钮和截图见[连续动作图文指引](notebook-feishu-onboarding/references/grouped-messages.md)。

测试通过后才设置定时，频率和保存位置由你确认。首次启动将已有云端资料记作基线，只同步之后新发现的资料，不自动导入全部旧库。未解析完成的单项保留重试，不阻塞后续正常资料；已有文档不会重复新建。

定时使用你当前 Agent 宿主的真实能力；当前窗口不支持时，Agent 会准备续接说明并带你进入定时入口。电脑或客户端关闭、后台等待权限、授权过期可能影响本地任务执行。只有任务自身的新资料试跑、文档读回和重复运行去重都通过，才报告“自动同步已启用”。

## 说明书和遇到问题怎么办

- [按组操作与配图](notebook-feishu-onboarding/references/grouped-messages.md)：微信接入、置顶、转发、飞书授权、用户验收和定时设置。
- [微信接入细节](notebook-feishu-onboarding/references/notehelper-setup.md) · [飞书连接检查与配置](notebook-feishu-onboarding/references/feishu-setup.md)。
- [测试后设置定时](notebook-feishu-onboarding/references/scheduling-setup.md) · [官方问题排查入口](notebook-feishu-onboarding/references/help-and-official-docs.md)。
- [官方来源与截图出处](notebook-feishu-onboarding/references/sources.md)。用户提问或页面不同时，Agent 应先查对应官方说明，再给出操作和链接。
- [提交问题](https://github.com/mingminwang962-eng/minmin-notehelper-feishu-starter/issues)：请描述卡住的步骤与报错，隐去密钥、授权码和私人资料。

## 内容创作模板与记录规则

包内提供不依赖制作者账号的四表模板、原版视图与看板。拍摄/剪辑使用通用状态，手动“拉取一下”和定时共用队列、去重、锁与双读回；重复拉取不覆盖改写和版本。详见[记录规则](notebook-feishu-onboarding/references/recording-rules.md)。新模板为空，不带个人账号、历史作品或假发布数据。

## 版本与验证

v0.9.1 补齐跨页资料选择、验收转定时和正文缓存恢复，修复看板说明换行。v0.9 增加可移植模板与共用同步流程；本地测试结果见验证说明。v0.8 原有下载兜底与手机图文指引保留。

v0.7 已通过 45 项本地离线测试，以及新用户 Agent 的 34 次独立运行期断言。它们验证流程、队列和恢复逻辑；真实账号授权、云端解析、飞书图片读回及宿主后台任务，需要在用户自己的环境完成验收。v0.7 当时未配置飞书看板。

[ZIP 校验值](https://tools.minmin11538.cn/notehelper/downloads/SHA256SUMS) · [当前版本与 SHA-256](https://tools.minmin11538.cn/notehelper/release.json)。

本项目是敏敏整理的独立接入引导包，非笔记同步助手、飞书或 WorkBuddy 官方产品。官方教程图片与用户提供的隐私处理图均保留来源说明。本仓库首页结构参考 [dbskill](https://github.com/dontbesilent2025/dbskill) 的“用途 → 快速开始 → 使用方式 → 帮助”组织方式，正文为本项目编写。

<!-- minmin-contact:start -->
## 联系敏敏

使用中有问题，或想交流新想法？欢迎联系敏敏。

<img src="contact/wechat-min11538.jpg" width="180" alt="敏敏的微信二维码">

微信：**min11538** · [敏敏的个人主页](https://me.minmin11538.cn/)
<!-- minmin-contact:end -->
